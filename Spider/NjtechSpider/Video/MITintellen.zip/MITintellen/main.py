import os


if __name__ == "__main__":
    os.chdir("C:\\Users\\22306\\Documents\\Python\\Spider\\NjtechSpider\\Video\\MITintellen")
    os.system('python MITintellen.py')
    os.system('python downloads.py')